# Open-Kode website

An open-source company website and project library built with HTML, CSS, JavaScript, a local Python server, and Netlify Functions for public catalog and content reads.

## Run locally

1. Install Python 3.10 or newer.
2. In PowerShell, start the local server:

   ```powershell
   cd D:\Codex\openkode-site
   python server.py
   ```

3. Open <http://127.0.0.1:8000>.

Restart `python server.py` after editing backend files. Opening `index.html` directly will not load detail routes, downloads, accounts, the playground API, or KODE.MINI API.

## Accounts and saved user data

Open <http://127.0.0.1:8000/console.html>, choose **Create account**, and register with an email and password. The address `mahir31891@gmail.com` receives the company-admin role. Other addresses get regular accounts.

The local database is `runtime/openkode-accounts.sqlite3`. It stores account email, display name, role, timestamps, and a salted scrypt password hash. It never stores readable passwords or sends email codes. Use the signed-in profile form to change a password. There is no email-based password reset because email delivery is not configured. The first owner account must be created from the computer running the server; the Python server binds to `127.0.0.1` by default.

## KODE.MINI API keys

The admin console’s **KODE.MINI API** section issues keys for the existing `AirMiniEngine` in `kode_mini_expanded_store/kode_mini.py`. This is the actual KODE.MINI Python assistant (rule-based, with no neural-network weights), not the separate DistilGPT2 fine-tuning experiment in `training/`.

The local OpenAI-compatible endpoint is:

```text
http://127.0.0.1:8000/v1/chat/completions
```

Example PowerShell request:

```powershell
$headers = @{ Authorization = "Bearer YOUR_OPENKODE_API_KEY" }
$body = @{ model = "kode-mini"; messages = @(@{ role = "user"; content = "Hello KODE.MINI" }) } | ConvertTo-Json -Depth 6
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8000/v1/chat/completions -Headers $headers -ContentType "application/json" -Body $body
```

Keys are random bearer secrets; only their SHA-256 hashes are stored in the local SQLite database. The raw key is shown once. The owner email gets permanent access. Subscriber key expiry is entered manually until a payment provider is connected. Keys are limited to 30 requests per minute and can be revoked from the console. Keep keys on your server; do not put them in public browser JavaScript or source control.

The Python server listens on localhost only by default. This makes the API usable on this computer, not by remote subscribers over the internet. Netlify serves the static site but does not run KODE.MINI’s Python engine or its local SQLite accounts and keys. Remote API access needs a separately hosted Python backend with HTTPS and persistent storage.

## KODE.MINI playground

The playground at `/playground` calls the existing Python assistant through `/api/chat`. User messages are held in memory while the process runs. They are not saved as account data. The large local knowledge-base files are not offered for download until their contents and redistribution license are confirmed.

## Separate local fine-tuning experiment

`training/` contains an optional, CPU-only DistilGPT2 fine-tuning experiment. Its trainer and API key tools are separate from KODE.MINI and are not used by the KODE.MINI console. The experiment adapts a pretrained model; it does not train a ChatGPT-scale model from scratch. Its local dataset and model weights are excluded from the website and source download. See [`training/README.md`](training/README.md).

## Item pages and downloads

Each model, project, and Windows app has its own detail URL. The library lists the KODE.MINI Python engine, website source, and four Windows builds: Clawd, Ganesha, Kode, and Minux. The `.exe` buttons download application files rather than source code. The KODE.MINI source identifies its license as MIT. The four Windows builds do not have matching source code or standalone license details in this workspace.

## Netlify

Run `npm run build` to prepare the `public/` static site. Netlify can host the public website and catalog. Account sign-in, password changes, website editing, KODE.MINI API keys, and model inference use the local Python backend and are not available on the static Netlify deployment. Do not treat an API key created on the local machine as remotely usable.

## Files

- `index.html`, `detail.html`, `playground.html`, `console.html` — home, item details, playground, and account console
- `styles.css`, `console.css` — responsive visual design
- `app.js`, `detail.js`, `playground.js`, `console.js` — library, detail pages, chat, and account/key management
- `server.py` — local Python server, scrypt accounts, KODE.MINI API keys, chat API, and downloads
- `netlify/functions/` — public Netlify catalog/content routes and local-backend notices
- `netlify.toml`, `scripts/prepare-netlify.mjs` — Netlify routes and static build preparation
- `content.json` — editable homepage copy
- `assets/favicon.png` — Open-Kode PNG browser icon
- `LICENSE` — MIT license for the website code
